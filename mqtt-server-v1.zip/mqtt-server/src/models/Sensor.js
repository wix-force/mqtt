import mongoose from "mongoose";

const SensorSchema = new mongoose.Schema({
  topic: { type: String, required: true },
  payload: { type: mongoose.Schema.Types.Mixed, required: true },
  receivedAt: { type: Date, default: () => new Date() }
});

export default mongoose.model("Sensor", SensorSchema);
