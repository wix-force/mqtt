import dotenv from "dotenv";
dotenv.config();

import mqtt from "mqtt";

const {
  MQTT_URL = "mqtt://broker.hivemq.com:1883",
  MQTT_TOPIC = "home/sensor1/data",
  CLIENT_ID = `fake-sensor-${Math.floor(Math.random()*10000)}`
} = process.env;

const client = mqtt.connect(MQTT_URL, { clientId: CLIENT_ID });

client.on("connect", () => {
  console.log("Fake sensor connected to:", MQTT_URL);
  setInterval(() => {
    const data = {
      temperature: Number((20 + Math.random() * 10).toFixed(2)),
      humidity: Number((40 + Math.random() * 20).toFixed(2)),
      ts: new Date().toISOString()
    };
    const payload = JSON.stringify(data);
    client.publish(MQTT_TOPIC, payload, { qos: 1, retain: false }, (err) => {
      if (err) console.error("Publish error:", err);
      else console.log("Published:", payload);
    });
  }, 3000);
});

client.on("error", (err) => {
  console.error("Publisher error:", err);
});
