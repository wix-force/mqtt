// subscriber.js
import mqtt from "mqtt";
import mongoose from "mongoose";

// ===================
// 1. MongoDB Connect
// ===================
async function connectDB() {
    try {
        await mongoose.connect("mongodb://127.0.0.1:27017/mqttDemo");
        console.log("MongoDB Connected");
    } catch (err) {
        console.error("❌ MongoDB Connection Failed", err);
    }
}

connectDB();

// ===================
// 2. Mongoose Schema
// ===================
const sensorSchema = new mongoose.Schema({
    temperature: Number,
    humidity: Number,
    ts: Date,
});

const SensorModel = mongoose.model("SensorData", sensorSchema);

// ==========================
// 3. MQTT Subscriber Setup
// ==========================

// Public broker (free test server)
const BROKER = "mqtt://broker.hivemq.com:1883";
const TOPIC = "home/sensor1/data";

const options = {
    clientId: "subscriber_" + Math.random().toString(16).slice(2),
    clean: true,
    reconnectPeriod: 2000, // auto reconnect every 2s
};

console.log("Connecting to MQTT broker...");

// Create client
const client = mqtt.connect(BROKER, options);

// ==========================
// 4. Connection Events
// ==========================

client.on("connect", () => {
    console.log("✅ Connected to MQTT broker:", BROKER);

    client.subscribe(TOPIC, { qos: 0 }, (err, granted) => {
        if (err) {
            console.error("❌ Subscription error:", err);
        } else {
            console.log("📡 Subscribed to:", TOPIC, "granted:", granted);
        }
    });
});

client.on("reconnect", () => {
    console.log("🔄 Reconnecting to MQTT...");
});

client.on("error", (err) => {
    console.error("❌ MQTT Connection Error:", err.message);
});

client.on("close", () => {
    console.log("🔌 Disconnected from MQTT");
});

// ==========================
// 5. Handle Incoming Messages
// ==========================
client.on("message", async (topic, message) => {
    try {
        const data = JSON.parse(message.toString());

        console.log("📥 Received:", data);

        //-- Save to MongoDB
        const saved = await SensorModel.create(data);
        console.log("💾 Saved to DB:", saved._id);

    } catch (err) {
        console.error("❌ Message Processing Error:", err);
    }
});
